({
    rerender : function(cmp, helper) {
       var ret = this.superRerender();
        return ret;
	}
})