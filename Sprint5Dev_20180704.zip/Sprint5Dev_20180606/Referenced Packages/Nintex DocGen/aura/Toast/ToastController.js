({
	doNothing : function(component, event, helper) { }
})